# 99 AI Image Commands — ChatGPT 2.0
### The fastest way to upgrade any image prompt

Version 1.0.0 · Launch price $2.68

---
## How to use this cheatsheet (30-second start)
1. Write your subject: `a lone samurai on a rooftop`
2. Pick **1–3 commands** and append them: `a lone samurai on a rooftop /cinematic /rimlight /cityscape`
3. Hit generate. That's it.

Rule of thumb for the best results:
- The commands are additive and stackable. More than 3–4 per prompt gets noisy.
- `/` commands work best **after the subject**, as a style tail.
- Combine **one style + one lighting + one camera** for a clean, premium look.

---

## 1. Quality & Resolution
| Command | Effect |
|---|---|
| `/4k` | Detailed 4K image |
| `/8k` | Ultra-detailed high-resolution |
| `/hdreal` | Enhanced photorealistic HD |
| `/ultrarealistic` | Maximum realism |

## 2. Camera & Angles
| Command | Effect |
|---|---|
| `/cinematic` | Cinematic light, composition, mood |
| `/droneview` | High aerial, drone-style |
| `/aerialview` | Top-down from great height |
| `/topdown` | Straight top-down |
| `/lowangle` | Dramatic low angle |
| `/highangle` | Camera looks down |
| `/sideview` | Side / profile view |
| `/closeup` | Close focus on subject |
| `/extremecloseup` | Ultra-close, high detail |
| `/wideangle` | Wide field of view |
| `/fisheye` | Fish-eye distortion |
| `/pov` | First-person frame |
| `/overtheshoulder` | Over-the-shoulder |
| `/birdseyeview` | Bird's-eye height |
| `/wormseyeview` | Extreme low-to-high |

## 3. Weather & Atmosphere
| Command | Effect |
|---|---|
| `/fog` | Atmospheric fog |
| `/mist` | Soft light haze |
| `/rainynight` | Rainy night atmosphere |
| `/rain` | Rain and wet look |
| `/storm` | Dramatic storm |
| `/snow` | Snow and winter mood |

## 4. Lighting & Time of Day
| Command | Effect |
|---|---|
| `/sunset` | Warm sunset light |
| `/sunrise` | Soft dawn light |
| `/goldenhour` | Golden-hour warmth |
| `/bluehour` | Cool blue dusk |
| `/moonlight` | Moonlit scene |
| `/neonlights` | Neon light effects |
| `/cyberpunk` | Cyberpunk aesthetic |
| `/darkmoody` | Dark, dramatic |
| `/softlighting` | Soft diffused light |
| `/dramaticlighting` | Strong contrast cinematic |
| `/rimlight` | Contour backlight |
| `/backlight` | Subject lit from behind |
| `/volumetriclight` | Visible light rays |
| `/godrays` | Dramatic sun rays |

## 5. Technical & Artistic Effects
| Command | Effect |
|---|---|
| `/studio` | Professional studio shot |
| `/filmgrain` | Analog film texture |
| `/anamorphic` | Widescreen anamorphic lens |
| `/bokeh` | Soft blurred bokeh |
| `/shallowdepth` | Sharp subject, blurred background |
| `/motionblur` | Dynamic motion blur |
| `/longexposure` | Long-exposure effect |
| `/freezeaction` | Frozen fast action |

## 6. Styles & Aesthetics
| Command | Effect |
|---|---|
| `/vintage` | Classic vintage look |
| `/retro` | Nostalgic retro style |
| `/oldmoney` | Timeless luxury |
| `/luxury` | Premium style |
| `/minimalist` | Clean minimalism |
| `/editorial` | Professional editorial |
| `/fashion` | High-fashion style |
| `/streetstyle` | Urban streetwear |
| `/magazinecover` | Magazine cover |

## 7. Camera & Film Emulation
| Command | Effect |
|---|---|
| `/polaroid` | Polaroid look |
| `/disposablecamera` | Disposable camera effect |
| `/35mmfilm` | Classic 35mm film |
| `/instantphoto` | Instant camera photo |

## 8. Locations & Environments
| Command | Effect |
|---|---|
| `/underwater` | Underwater scene |
| `/space` | Space environment |
| `/desert` | Desert landscape |
| `/forest` | Forest location |
| `/mountains` | Dramatic mountains |
| `/beach` | Coast / beach |
| `/cityscape` | Cityscape |
| `/nightcity` | Night city |

## 9. Genres & Universes
| Command | Effect |
|---|---|
| `/futuristic` | Futuristic design |
| `/postapocalyptic` | Ruined world |
| `/fantasy` | Magical fantasy world |
| `/scifi` | Science fiction |
| `/medieval` | Middle Ages |
| `/samurai` | Japanese samurai |
| `/noir` | Dark noir contrast |
| `/detective` | Mystery detective mood |
| `/superhero` | Epic superhero visual |

## 10. Artistic Mediums
| Command | Effect |
|---|---|
| `/anime` | Anime style |
| `/comicbook` | Drawn comic |
| `/oilpainting` | Oil painting |
| `/watercolor` | Soft watercolor |
| `/sketch` | Hand-drawn sketch |
| `/claystyle` | Clay / plasticine |
| `/3drender` | High-quality 3D |
| `/isometric` | Isometric 3D |
| `/miniature` | Miniature world |
| `/tiltshift` | Tilt-shift miniature |
| `/papercraft` | Paper craft |

## 11. Materials & Special Effects
| Command | Effect |
|---|---|
| `/glassart` | Transparent glass aesthetic |
| `/metal` | Polished metal surface |
| `/marble` | Marble texture |
| `/wood` | Natural wood grain |
| `/velvet` | Rich velvet fabric |
| `/neon` | Neon glow |
| `/holographic` | Holographic iridescence |
| `/smoke` | Smoke and haze |

> Total: 99 commands. Built from the public ChatGPT Image 2.0 command set.

---
*Educational reference. Results depend on the model. Not affiliated with OpenAI.*
