# PRO RECIPES — How to stack the 99 commands
### Turn a flat prompt into a masterpiece in seconds

The real value isn't the command list — it's knowing **which ones to combine**. These are battle-tested combinations. Copy, paste, swap the subject.

## The formula
`[SUBJECT] + [1 STYLE] + [1 LIGHT] + [1 CAMERA]`

Pick one from each column. Don't stack 6 commands or the image gets muddy.

---

## Recipe 1 — Cinematic Poster
**Subject:** a lone samurai on a rooftop
**Stack:** `/cinematic /rimlight /nightcity /35mmfilm`
**Full prompt:**
> a lone samurai on a rooftop /cinematic /rimlight /nightcity /35mmfilm

## Recipe 2 — Luxury Product Shot
**Subject:** a premium watch on black stone
**Stack:** `/luxury /studio /dramaticlighting /closeup`
**Full prompt:**
> a premium watch on black stone /luxury /studio /dramaticlighting /closeup

## Recipe 3 — Moody Editorial
**Subject:** a woman in a red coat at a crosswalk
**Stack:** `/editorial /rainynight /bokeh /magazinecover`
**Full prompt:**
> a woman in a red coat at a crosswalk /editorial /rainynight /bokeh /magazinecover

## Recipe 4 — Dreamy Fantasy
**Subject:** a castle floating above clouds
**Stack:** `/fantasy /volumetriclight /godrays /aerialview`
**Full prompt:**
> a castle floating above clouds /fantasy /volumetriclight /godrays /aerialview

## Recipe 5 — 3D Miniature
**Subject:** a tiny village at the forest edge
**Stack:** `/3drender /miniature /sunrise /tiltshift`
**Full prompt:**
> a tiny village at the forest edge /3drender /miniature /sunrise /tiltshift

## Recipe 6 — Cyberpunk Street
**Subject:** a courier on a speeder through a neon alley
**Stack:** `/cyberpunk /neonlights /motionblur /streetstyle`
**Full prompt:**
> a courier on a speeder through a neon alley /cyberpunk /neonlights /motionblur /streetstyle

## Recipe 7 — Film Look
**Subject:** a diner at dawn
**Stack:** `/retro /goldenhour /filmgrain /disposablecamera`
**Full prompt:**
> a diner at dawn /retro /goldenhour /filmgrain /disposablecamera

## Recipe 8 — Epic Landscape
**Subject:** a lone climber on a ridge
**Stack:** `/ultrarealistic /mountains /dramaticlighting /wideangle`
**Full prompt:**
> a lone climber on a ridge /ultrarealistic /mountains /dramaticlighting /wideangle

---

## Pro cheat — the "3-second swap"
Keep a **subject template** and change only the recipe:
> {subject} /cinematic /goldenhour /bokeh
> {subject} /luxury /studio /closeup
> {subject} /fantasy /volumetriclight /aerialview

## When to use which
| Goal | Use |
|---|---|
| Real estate / product | `/luxury /studio /dramaticlighting` |
| Photographic / human | `/cinematic /35mmfilm /bokeh` |
| Fantasy / concept art | `/fantasy /volumetriclight` |
| Clean minimal | `/minimalist /softlighting /studio` |
| Bold / dynamic | `/cyberpunk /neonlights /motionblur` |
| Print / editorial | `/editorial /magazinecover /filmgrain` |

---
*Educational reference. Results depend on the model.*
