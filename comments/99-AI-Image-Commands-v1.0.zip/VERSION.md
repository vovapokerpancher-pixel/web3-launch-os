# VERSION & Changelog — Pro Command Library

## Release
- **Version:** 1.0.0
- **Status:** v1
- **Released:** 2026-08-31

## Includes
- 99 commands across 11 categories (`command_catalog.md`).
- 8 pro recipes + swap cheat sheet (`recipes.md`).
- 12+ copy-paste example prompts (`examples/best_of.md`).
- Start Here onboarding.

## Update & support policy
- Updates are additive (new commands, new recipes). You'll get notified.
- Support: a creator support channel. Include your order id.
- Customization: send requests via support; logged, prioritized.

## Changelog
| Version | Date | Notes |
|---|---|---|
| 1.0.0 | 2026-08-31 | Initial release. |

## License
See `LICENSE.txt` — personal/business use for the purchaser. No redistribution/resale.
