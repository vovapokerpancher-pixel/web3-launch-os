# Example prompts — copy these
Elevated prompts using the 99 commands. Swap the bracketed subject.

## Portrait / Human
> a [profession] in [setting] /editorial /magazinecover /filmgrain
> a [age] [person] at [time of day] /cinematic /bokeh /35mmfilm
> a [person] in a [color] coat /luxury /studio /dramaticlighting

## Product / Commerce
> a [product] on [surface] /studio /luxury /closeup
> a [product] floating on [background] /3drender /minimalist /softlighting
> a [product] with [material] /luxury /godrays /shallowdepth

## Scene / Landscape
> a [landscape] at [time] /ultrarealistic /mountains /dramaticlighting
> a [city] street in the rain /nightcity /rainynight /motionblur
> a [region] village /fantasy /volumetriclight /aerialview

## Fantasy / Concept
> a [creature] in a [world] /fantasy /godrays /medieval
> a [tech] machine /scifi /neonlights /isometric
> a [object] made of [material] /glassart /holographic /closeup

## Film / Mood
> a cozy [room] /retro /goldenhour /filmgrain
> a quiet [place] at dawn /goldenhour /softlighting /wideangle
> a [person] in a dark alley /noir /rimlight /nightcity

---
*Educational reference. Results depend on the model.*
