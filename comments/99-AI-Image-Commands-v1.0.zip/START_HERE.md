# START HERE — 99 AI Image Commands (ChatGPT 2.0)

You're 30 seconds from a better image. Do this:

## The 30-second path
1. Open `command_catalog.md` — the full 99 commands, organized by category.
2. Open `recipes.md` — the proven combinations (copy/paste, swap the subject).
3. Write your subject, pick 3 commands, generate.

## The formula (memorize this)
`[SUBJECT] + [1 STYLE] + [1 LIGHT] + [1 CAMERA]`

## What's in this pack
| File | What it is |
|---|---|
| `command_catalog.md` | All 99 commands, grouped in 11 categories |
| `recipes.md` | 8 pro recipes + 3-second swap cheat sheet |
| `examples/best_of.md` | Example brand-new prompts you can copy |
| `img/cover.png` | Product key visual |

## Quick tips
- Stack **3–4 commands max** per prompt.
- Appending `/` commands **after the subject** works best.
- Buy/convert to your generator's accepted format if a command isn't recognized.

## Honest note
- Results depend on the AI model. Some `/` tags map to natural-language descriptions.
- This is a reference to make prompts richer — not a guarantee of output.

## Support & updates
See `VERSION.md` for versioning and update policy.

---
Version 1.0.0
