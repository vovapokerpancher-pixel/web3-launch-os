# 25 Prompt Upgrades (subject → premium)

Swap the [bracketed] part to reuse. These are ready — just change the subject.

## Lifestyle / product
1. a [product] on [surface] /luxury /studio /dramaticlighting, macro detail
2. a [product] in [scene] /cinematic /goldenhour /bokeh, soft reflection
3. a [product] on black stone /luxury /studio /rimlight, shallow depth
4. a [device] on a desk /editorial /backlight /35mmfilm, dust in the air
5. a [watch] floating /3drender /minimalist /softlighting, clean background

## Portrait / human
6. a [person] in [color] coat /editorial /magazinecover /filmgrain
7. a [person] in the rain /noir /rainynight /rimlight, wet street
8. a [person] at dusk /cinematic /goldenhour /bokeh, backlit
9. a [person] in a studio /fashion /studio /dramaticlighting, sharp shadow
10. a [person] on the street /streetstyle /nightcity /motionblur, neon glow

## Scene / landscape
11. a [city] street /editorial /rainynight /motionblur, neon reflections
12. a [landscape] at dawn /ultrarealistic /mountains /volumetriclight, god rays
13. a quiet [place] /minimalist /softlighting /bokeh, fog
14. a [forest] path /cinematic /volumetriclight /godrays, mist
15. a [beach] at sunset /ultrarealistic /goldenhour /wideangle, soft waves

## Fantasy / concept
16. a [castle] in the clouds /fantasy /volumetriclight /aerialview, god rays
17. a [creature] in a [world] /fantasy /dramaticlighting /medieval, rim light
18. a [machine] /scifi /neonlights /isometric, chrome
19. an [object] made of [material] /glassart /holographic /closeup, refraction
20. a [hero] /superhero /cinematic /dramaticlighting /lowangle, dust

## Film / mood
21. a [room] at night /retro /goldenhour /filmgrain, warm lamp
22. a [diner] at dawn /editorial /goldenhour /35mmfilm, steam
23. a [alley] at midnight /noir /moonlight /rimlight, fog
24. a [road] in the fog /cinematic /volumetriclight /longexposure, headlights
25. a [rooftop] under the stars /space /moonlight /wideangle, silhouette

---
*Reference tool. Results depend on the model.*
