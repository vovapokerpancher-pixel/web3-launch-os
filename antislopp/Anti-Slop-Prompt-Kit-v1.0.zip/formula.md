# The Anti-Slop Formula

## Why AI images look "slop"
Most image models, given a bare subject, return the **most generic possible** version: flat light, mid-tone colors, boring framing, no mood. That's "slop."

## The fix — 3 lines
Add these three to ANY subject prompt:

1. **STYLE** — one word that sets the look (e.g. `/cinematic`, `/editorial`, `/luxury`).
2. **DETAIL** — specific texture/light/detail (e.g. `soft fur`, `wet asphalt`, `golden rim light`).
3. **LIGHT** — one lighting tag (e.g. `/goldenhour`, `/dramaticlighting`, `/bokeh`).

## The formula
```
[SUBJECT] + [STYLE] + [DETAIL] + [LIGHT]
```

## Before → After
| Before (bare) | After (formula) |
|---|---|
| `a cat` | `a cat on a windowsill /cinematic /goldenhour /bokeh, soft fur` |
| `a watch` | `a watch on black marble /luxury /studio /dramaticlighting, macro detail` |
| `a city` | `a city street in the rain /editorial /rainynight /motionblur, neon reflections` |
| `a castle` | `a castle floating in clouds /fantasy /volumetriclight /aerialview, god rays` |
| `a portrait` | `a woman in a red coat /editorial /magazinecover /filmgrain, soft window light` |

## Rule of thumb
- **Max 3–4 tags** — after that it gets muddy.
- Put the tags **after** the subject.
- Pick ONE style, ONE light, ONE camera — not a pile.

## The "3-second swap"
Keep a template and change only the subject:
> {subject} /cinematic /goldenhour /bokeh, soft diffuse light
> {subject} /luxury /studio /dramaticlighting, macro detail
> {subject} /editorial /rainynight /motionblur, neon reflections

---
*Reference tool. Results depend on the model.*
