# Start Here — Anti-Slop Prompt Kit
### Turn a boring AI image into a premium one

Version 1.0.0 · Symbolic price $0.99

## The 3-line formula (that fixes 90% of slop)
```
[SUBJECT] + [STYLE*] + [DETAIL*] + [LIGHT*]
```
Real example:
- **Before:** `a cat`
- **After:** `a cat on a windowsill /cinematic /goldenhour /bokeh, soft fur, shallow depth`

The kit gives you 25 ready upgrade prompts. Copy, paste, swap the subject.

## What you get
| File | What it is |
|---|---|
| `formula.md` | The 3-line anti-slop formula + how to use it |
| `examples/25_upgrades.md` | 25 copy-paste prompt upgrades (subject → premium) |
| `img/before.png` | A "before" image (the problem) |
| `img/after.png` | The same subject after the formula (the result) |

## 30-second start
1. Open `formula.md` — read the formula (30 sec).
2. Pick any example in `examples/25_upgrades.md`, swap `[subject]`.
3. Paste into your AI image tool.

## Honest note
- This is a reference. Results depend on the model you use.
- The before/after are real examples showing the difference the formula makes.

## Support & updates
See `VERSION.md`. Reference tool, not affiliated with OpenAI.
