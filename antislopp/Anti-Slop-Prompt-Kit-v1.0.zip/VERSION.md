# VERSION & Changelog — Anti-Slop Prompt Kit

## Release
- **Version:** 1.0.0
- **Price:** $0.99 (symbolic)
- **Released:** 2026-08-31

## Includes
- `formula.md` — the 3-line anti-slop formula.
- `examples/25_upgrades.md` — 25 ready upgrade prompts.
- `img/before.png` + `img/after.png` — honest before/after demonstration.

## Update & support
- Updates additive (new formula variants, more prompts). Notified on update.
- Support: creator support channel; include order id.
- Reference tool, not affiliated with OpenAI. Results depend on model.

## Changelog
| Version | Date | Notes |
|---|---|---|
| 1.0.0 | 2026-08-31 | Initial release. |

## License
See LICENSE.txt — personal/business use for the purchaser. No redistribution/resale.
