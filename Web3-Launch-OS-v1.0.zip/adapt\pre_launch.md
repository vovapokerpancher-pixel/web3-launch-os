# Scenario A — Pre-Launch (before your token/product is out)

Goal: build audience + trust before launch. First value in 20 min.

## 20-minute path
1. Open `kpi_calculator.csv` → set baseline (current followers, weekly goal +250).
2. Open `content_calendar.csv` → fill Day 1–7 with "build in public" content using `campaign_planner.md` hooks.
3. Set up the onboarding step in `sop_community.md` so the first members have a clear action.

## Focus (what to do now)
- **Awareness** — post build-in-public threads consistently (1/day on primary channel).
- **Proof** — share small real wins and screenshots, not promises.
- **Community** — get the first 50 engaged members; retention matters more than size.

## Metrics to move
- New followers/week (target). 
- DMs engaged / week.
- Community new members/week.

## What NOT to do
- No price-talk or "to the moon" hype.
- No promises of token price/returns.
- Don't buy followers or fake engagement.
