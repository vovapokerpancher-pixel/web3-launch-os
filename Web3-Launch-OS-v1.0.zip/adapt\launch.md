# Scenario B — Launch (you've just launched)

Goal: convert audience into actual traction + accountability. First value in 20 min.

## 20-minute path
1. Fill `campaign_planner.md` with your 7-day launch window (channels, cadence, metrics, stop-conditions).
2. Use `assets/sop_community.md` to handle the influx (onboarding + moderation + escalation).
3. Open `objection_library.md` — it has the questions buyers/community will ask.

## Focus
- **Consistency** — stick to cadence; volume without structure burns out.
- **Proof, not promises** — publish real results/charts.
- **Respond fast** — time-to-first-response is the #1 predictor of healthy community.

## Metrics to move
- DMs engaged, replies, new members, retention 7d, CAC.
- Watch quality: refunds/purchases (expectations match reality?).

## What NOT to do
- No guaranteed-growth or price claims — compliance + reputation.
- No spam / mass unsolicited DMs.
- Don't auto-reply to disputes/refunds.
