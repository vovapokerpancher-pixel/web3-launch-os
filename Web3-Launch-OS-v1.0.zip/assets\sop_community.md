# Community SOP — Web3 Launch OS

The day-to-day operating manual for your Discord / Telegram community. Small teams can't wing it; use this to stay consistent without burning out.

## 1. Onboarding (every new member, first 24h)
- Welcome message within 15 min (automate or delegate).
- Pin: purpose of the server + how to get help + rules.
- Ask 1 qualification question in #welcome (e.g., "what are you building?").
- Give a clear first action: introduce yourself.

## 2. Daily rhythm (5–10 min each)
| When | What | Metric |
|---|---|---|
| Morning | Post 1 announcement + 1 tip | Engagement |
| Midday | Reply to new questions | Time-to-first-response |
| Evening | Highlight a member / win | Participation |

## 3. Moderation rules (anti-spam & safety)
- No price talk / "when Lambo" / perma-shill. Link to rules, delete, warn.
- No spam: 3-strike policy (warn → mute → ban).
- Never answer disputes/refunds in public — take to support channel.
- Keep it factual; no financial promises by you or mods.

## 4. Roles & permissions
- `@mods`: cleanup, rule enforcement, support intake.
- `@community`: engagement, onboarding.
- Never give a mod payment/refund authority.

## 5. Weekly community review (30 min)
- Active weekly vs total.
- Time to first response.
- Top 3 questions repeated → this is product signal.
- What to improve.

## 6. Escalation (human only)
- Refund / payment issue → **human**, not automated.
- Dispute / chargeback → human alert, no auto reply.
- Legal / safety issue → pause and escalate.

## Compliance notes
- No price or investment signals. Educational/ops only.
- Collect minimal personal data; no unnecessary PII.
