# Allowed Research Sources — Web3 Launch OS

Only ToS-compatible, official, and public sources. No scraping, no bypass, no spam.

## Compliant sources
- **Official APIs:** Reddit via official PRAW/OAuth; Product Hunt public pages; GitHub public API; official docs.
- **Public pages:** Product Hunt product/review pages (read-only), official documentation, public company pages.
- **Own materials:** your own legal documents, interviews you conducted, research you paid for.

## Explicitly NOT allowed
- Third-party scrapers / aggregators of Reddit (e.g., generic "reddit API" services, ScrapiReddit-type tools, MCP reddit scrapers).
- Bypassing Cloudflare, CAPTCHA, paywalls, rate limits, or authentication.
- Mass unsolicited messaging, spam, fake engagement, fake reviews.
- Non-license materials, plagiarism, copied courses/bases.
- Financial promises, price signals, investment advice, "signal" schemes, betting/gray schemes.

## Rules for every record
Each signal must have: source_url, source_type, exact quote/observation, a date checked, and evidence confidence. Mark `human_verified: false` until manually confirmed.
