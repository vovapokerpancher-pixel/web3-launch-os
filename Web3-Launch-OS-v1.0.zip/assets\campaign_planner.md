# Campaign Planner — Web3 Launch OS

Reusable template for a launch / traction campaign. Copy this, fill it, run it.

## 1. Objective (one measurable sentence)
> e.g. "Add 300 qualified community members in 30 days without paid ads."

## 2. Audience segment
Who specifically? (role + situation). Keep it narrow.

## 3. Core message (hook)
One line a person in that segment would recognize.

## 4. Channels (1 primary + 1 backup)
- Primary: ____
- Backup: ____

## 5. Assets needed
- Content: ____
- Proof / case: ____
- CTA: ____

## 6. Cadence
| Day | Action | Owner | Status |
|---|---|---|---|
| 1 | ____ | ____ | |
| 2 | ____ | ____ | |
| 3 | ____ | ____ | |
| 4 | ____ | ____ | |
| 5 | ____ | ____ | |
| 6 | ____ | ____ | |
| 7 | ____ | ____ | |

## 7. Metrics
| Metric | Baseline | Target |
|---|---|---|
| Reach | | |
| Engagement | | |
| New members | | |
| Retention (7d) | | |
| Cost per acquisition | | |

## 8. Stop conditions
- If reach > ___ with < __ engagements → pivot hook.
- If CAC > ___ → stop that channel.

## 9. Retro (after 7 days)
- What worked.
- What didn't.
- What to change.
- Decision: Continue / Iterate / Kill.
