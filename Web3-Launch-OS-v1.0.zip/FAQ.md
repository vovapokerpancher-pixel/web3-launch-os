# FAQ — Web3 Launch OS

## How do I get my first value?
Follow `START_HERE.md`. The 20-minute path gets you a measurable plan + a working content calendar.

## What do I get?
The full file tree in `03_file_tree.md`: calculators, content calendar, campaign planner, community SOP, objection library, examples, adaptation scenarios, and n8n workflows.

## Do you run marketing for me?
No. This is a self-serve operating system, not an agency. You get the process and tools; you execute.

## Will this increase my token price?
No, and anyone who promises that is misleading you. It's an operating system for marketing and community. Not financial advice. Results depend on your execution.

## What if it doesn't fit me?
The three adaptation scenarios (pre-launch / launch / scale) let you pick the relevant path. If it truly doesn't help, reach out within the refund window per policy.

## Refund policy
Plain and honest:
- **Within 7 days** of purchase and **before** you've used the templates — ask for a refund via the support channel.
- If you've started working through the system, we'll help you get value rather than auto-refund.
- No vague "instant/no-questions-asked" claims. Refunds handled by a human.

## Updates
See `VERSION.md` for versioning, changelog, update and support policy.

## Is it subscriber-based?
No. One-time purchase at the current price. No subscription.

## Support
Use the support channel listed in `VERSION.md`. Keep requests specific and include your purchase/order id.
