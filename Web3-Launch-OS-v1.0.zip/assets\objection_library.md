# Objection Library — Web3 Launch OS

Common objections when selling / DMing / in community, and honest responses.

## 1. "Is this free ChatGPT?" 
> No. This is a ready operating system — calculator, content calendar, community SOP, campaign planner, and automation. You execute, not build from scratch.

## 2. "Will this make my token go up?" 
> No. Nothing can promise that. It's an operating system for marketing and community. Results depend on your execution. This is not financial advice.

## 3. "Will it work for me?" 
> It gives structure, tools, and filled examples. Whether it works depends on how consistently you use it. I don't guarantee outcomes — anyone who does is misleading you.

## 4. "Why is it only $29 / not worth it?" 
> It's priced as an impulse decision, less than an hour of agency time, and you can check the filled examples before committing.

## 5. "Do you run it for me?" 
> No — this is a self-serve operating system, not an agency. The value is the repeatable process.

## 6. "I've tried toolkits before, they're PDFs." 
> This ships with real CSV calculators, SOPs, planner, and n8n workflows you can actually run — not just a PDF.

## 7. "Refund policy?" 
> Stated plainly in FAQ.md. No vague "no questions asked" claims.

## Handling hot buttons
- Price talk in community → redirect to rules, not argue.
- Refund request → **human**, get reason, respect policy.
