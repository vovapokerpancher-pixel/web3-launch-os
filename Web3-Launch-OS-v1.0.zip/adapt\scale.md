# Scenario C — Scale (you want repeatable growth)

Goal: turn traction into a repeatable, sustainable engine. First value in 20 min.

## 20-minute path
1. Fill `kpi_calculator.csv` fully with per-channel metrics so you can double down on what works.
2. Review `campaign_planner.md` retro — keep the winning channel, cut losers.
3. Configure the `n8n_workflows/` automation (signal collection, daily report) to free your time.

## Focus
- **Double down** on the 1 best channel; drop the rest.
- **Automate** the repetitive reporting/handoffs (n8n) so you can focus on craft.
- **Retention** — active/cohort and advocacy (referrals + case studies) become the moat.

## Metrics to move
- Retention (active/cohort), acquisition cost, advocacy (referrals/share).
- Refund rate (keep expectations aligned).

## What NOT to do
- Don't buy fake engagement/spam.
- Don't over-diversify channels (dilution).
- No financial-return promises.
