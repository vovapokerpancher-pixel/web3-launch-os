# VERSION & Changelog — Web3 Launch OS

## Release info
- **Version:** 1.0.0
- **Status:** MVP
- **Released:** 2026-08-31

## What's included (v1.0.0)
- KPI calculator (CSV, 5 tabs/trackers).
- 30-day content calendar + filled example.
- Campaign planner (reusable, with stop-conditions + retro).
- Community SOP (onboarding, daily rhythm, moderation, escalation).
- Objection library (honest responses).
- 3 adaptation scenarios: pre-launch / launch / scale.
- 5 small n8n workflows.
- Start Here onboarding.

## Update & support policy
- **Updates:** future versions are additive (new templates/scenarios). You get notified; core updates are free within your access.
- **Support:** `support@your-domain.example` (placeholder; replace when live) or in-product channel. Include your order id. Response target: ≤ 24h business.
- **Feature requests:** send via support; logged, prioritized. Not every request ships.

## Changelog
| Version | Date | Notes |
|---|---|---|
| 1.0.0 | 2026-08-31 | Initial MVP release. |

## License
See `LICENSE.txt` — personal/business use for the purchaser. No redistribution or resale.
