# START HERE — Web3 Launch OS

Welcome. You'll get your first value in under 20 minutes. Follow in order.

## The 20-minute path
1. **Open the KPI calculator** (`assets/kpi_calculator.csv`). Fill ~5 cells in each tab: your project, target audience, current followers, weekly posting cadence, community size.
2. **Open the content calendar** (`assets/content_calendar.csv`). Save a copy. The filled example is in `examples/filled_content_calendar.csv` — copy the structure.
3. **Pick a scenario that fits you** in `adapt/` (pre-launch / launch / scale). Read the 10-minute section.
4. **Draft your next 7 days** in the calendar using the hooks from `assets/campaign_planner.md`.
5. You now have: a measurable traction plan + a working content calendar + a community SOP (if you have a Discord/Telegram).

## What you got
| Asset | What it does |
|---|---|
| `assets/kpi_calculator.csv` | Tracks audience, engagement, community, retention |
| `assets/content_calendar.csv` | 30-day posting plan (template) |
| `assets/campaign_planner.md` | Reusable campaign/launch plan |
| `assets/sop_community.md` | Community SOP (onboarding, moderation, anti-spam) |
| `assets/objection_library.md` | Objections + how to respond |
| `adapt/` | 3 scenarios: pre-launch / launch / scale |
| `examples/` | Pre-filled examples of every template |
| `n8n_workflows/` | Small automation workflows |

## Where to go after
- `FAQ.md` — common questions + refund policy.
- `VERSION.md` — version, changelog, update policy.
- `resources/sources.md` — allowed research sources.

## Honesty (so expectations match reality)
This is an operating system for marketing and community. **It does not** guarantee token price increases, "100x", or financial returns. Results depend on your execution. It is not financial advice.

## Support
See `VERSION.md` for the update/support policy and how to request help.

--- 
Version: 1.0.0 · Updated: 2026-08-31
